Use the **Browse** button to find a file that contains a skeleSim object
stored in R binary format.  Once the file is loaded, choose the
correct skeleSim object from the **select parameter object** menu.
