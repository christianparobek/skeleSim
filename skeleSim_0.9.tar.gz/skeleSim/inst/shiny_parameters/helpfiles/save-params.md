Selecting the **Save params** button will save the current skeleSim object to the disk
