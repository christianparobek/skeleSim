Change the history by single-clicking on a source population and
double clicking on a sink population at the time depth that
coalescence should occur

