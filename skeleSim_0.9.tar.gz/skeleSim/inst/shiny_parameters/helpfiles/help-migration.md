Columns represent _from_ and rows represent _to_.  Migration models
determine the structure of the matrix.  The migration multiplier
changes the elements in the matrix by this factor (direct
multiplication).  To enter arbitrary elements in the matrix choose the
"user" migration model.  Spatial arrangements (twoD, twoDwDiagonal,
and distance) require that the populations be arranged in rows and
columns.  The product of the rows and columns must equal the number of
populations.  In addition, twoD and twoDwDiagonal have to have both rows and columns > 1.


